print("Hello Foo.")
